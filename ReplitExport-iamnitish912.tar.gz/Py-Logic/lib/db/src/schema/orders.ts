import { pgTable, serial, text, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  placedAt: timestamp("placed_at", { withTimezone: true }).notNull().defaultNow(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(),
  orderType: text("order_type").notNull(),
  quantity: text("quantity").notNull(),
  price: text("price"),
  stopPrice: text("stop_price"),
  timeInForce: text("time_in_force"),
  success: boolean("success").notNull(),
  orderId: text("order_id"),
  status: text("status"),
  executedQty: text("executed_qty"),
  avgPrice: text("avg_price"),
  rawRequest: jsonb("raw_request"),
  rawResponse: jsonb("raw_response"),
  errorMessage: text("error_message"),
});

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  id: true,
  placedAt: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
