# Binance Futures Testnet Trading Bot

A clean, structured Python CLI application for placing orders on Binance Futures Testnet (USDT-M). Supports Market, Limit, and Stop-Limit orders with full input validation, structured logging, and robust error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance REST API client (signing, requests, error handling)
│   ├── orders.py          # Order placement logic + output formatting
│   ├── validators.py      # Input validation
│   └── logging_config.py # Rotating file logger + console logger
├── logs/
│   └── trading_bot.log    # Auto-created on first run
├── cli.py                 # CLI entry point (argparse)
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Get Binance Futures Testnet credentials

1. Go to [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Log in with GitHub or Google
3. Navigate to **API Key** tab and generate a new key pair
4. Save your **API Key** and **Secret Key**

### 2. Install dependencies

```bash
cd trading_bot
pip install -r requirements.txt
```

### 3. Set your API credentials

**Option A — environment variables (recommended):**

```bash
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"
```

**Option B — `.env` file:**

Create `trading_bot/.env`:
```
BINANCE_API_KEY=your_api_key_here
BINANCE_API_SECRET=your_api_secret_here
```

Then load it before running:
```bash
export $(cat .env | xargs)
```

**Option C — CLI flags (not recommended for production):**

```bash
python cli.py --api-key YOUR_KEY --api-secret YOUR_SECRET ...
```

---

## How to Run

Run all commands from inside the `trading_bot/` directory.

### Market Order

```bash
# Market BUY 0.001 BTC
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

# Market SELL 0.05 ETH
python cli.py --symbol ETHUSDT --side SELL --type MARKET --quantity 0.05
```

### Limit Order

```bash
# Limit BUY 0.001 BTC at $30,000 (GTC)
python cli.py --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.001 --price 30000

# Limit SELL 0.05 ETH at $1,800 (IOC)
python cli.py --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.05 --price 1800 --time-in-force IOC
```

### Stop-Limit Order *(bonus)*

```bash
# Stop-Limit BUY: triggers at $30,500, places limit at $31,000
python cli.py \
  --symbol BTCUSDT \
  --side BUY \
  --type STOP_LIMIT \
  --quantity 0.001 \
  --price 31000 \
  --stop-price 30500

# Stop-Limit SELL: triggers at $1,750, places limit at $1,700
python cli.py \
  --symbol ETHUSDT \
  --side SELL \
  --type STOP_LIMIT \
  --quantity 0.05 \
  --price 1700 \
  --stop-price 1750
```

### Help

```bash
python cli.py --help
```

---

## CLI Arguments

| Flag | Required | Description |
|---|---|---|
| `--symbol` | ✅ | Trading pair, e.g. `BTCUSDT` |
| `--side` | ✅ | `BUY` or `SELL` |
| `--type` | ✅ | `MARKET`, `LIMIT`, or `STOP_LIMIT` |
| `--quantity` | ✅ | Order quantity (positive number) |
| `--price` | LIMIT / STOP_LIMIT | Limit price |
| `--stop-price` | STOP_LIMIT | Stop trigger price |
| `--time-in-force` | optional | `GTC` (default), `IOC`, `FOK`, `GTX` |
| `--api-key` | optional | Overrides `BINANCE_API_KEY` env var |
| `--api-secret` | optional | Overrides `BINANCE_API_SECRET` env var |

---

## Sample Output

```
╔══════════════════════════════════════════════════════╗
║     Binance Futures Testnet — Trading Bot  v1.0      ║
╚══════════════════════════════════════════════════════╝

┌─ Order Request ─────────────────────────────────
│  Symbol      : BTCUSDT
│  Side        : BUY
│  Type        : MARKET
│  Quantity    : 0.001
└─────────────────────────────────────────────────

┌─ Order Response ────────────────────────────────
│  Order ID    : 3485847384
│  Client ID   : abc123xyz
│  Symbol      : BTCUSDT
│  Side        : BUY
│  Type        : MARKET
│  Status      : FILLED
│  Orig Qty    : 0.001
│  Exec Qty    : 0.001
│  Avg Price   : 43521.50
└─────────────────────────────────────────────────

  ✔  Order placed successfully!
```

---

## Logging

All API requests, responses, and errors are automatically logged to `logs/trading_bot.log`.

- Log file rotates at 5 MB, keeps 3 backups
- Debug level in the log file (full request/response detail)
- Warning+ level to the console (only errors shown there)

Example log entries:
```
2025-06-12T10:30:01 | DEBUG    | bot.client | REQUEST POST /fapi/v1/order params={'symbol': 'BTCUSDT', 'side': 'BUY', 'type': 'MARKET', 'quantity': 0.001, 'timestamp': 1718185801234}
2025-06-12T10:30:02 | DEBUG    | bot.client | RESPONSE POST /fapi/v1/order status=200 body={"orderId":3485847384,...}
2025-06-12T10:30:02 | INFO     | bot.orders | MARKET order response: {'orderId': 3485847384, 'status': 'FILLED', ...}
2025-06-12T10:30:02 | INFO     | bot.cli    | Order placed successfully | orderId=3485847384
```

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| Missing required flag (e.g. `--price` for LIMIT) | Validation error printed, exits with code 1 |
| Invalid symbol / quantity / price | Validation error with clear message |
| Binance API error (e.g. insufficient margin) | API error code + message printed |
| Network failure | Clear connectivity error message |
| Request timeout | Timeout message with endpoint name |
| Missing API credentials | Configuration error with instructions |

---

## Assumptions

- Testnet base URL: `https://testnet.binancefuture.com`
- All orders are placed on **USDT-M perpetual futures**
- Credentials are supplied via environment variables (not hardcoded)
- Stop-Limit uses Binance's `STOP` order type (futures equivalent of stop-limit)
- No position management or balance checks are performed — the bot is a pure order-placement tool
- Quantity precision must match the symbol's lot size rules on the testnet (Binance will return an error if it doesn't)

---

## Dependencies

```
requests>=2.31.0       # HTTP client for REST API calls
python-dotenv>=1.0.0   # Optional .env file support
```

No third-party Binance SDK is used — all API calls are direct REST with HMAC-SHA256 signing.
