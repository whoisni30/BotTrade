from typing import Any, Dict, Optional

from .client import BinanceFuturesClient
from .logging_config import get_logger

logger = get_logger(__name__)


class OrderPlacer:
    def __init__(self, client: BinanceFuturesClient):
        self.client = client

    def place_market_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": quantity,
        }
        logger.info(
            "Placing MARKET order | symbol=%s side=%s qty=%s",
            symbol,
            side,
            quantity,
        )
        response = self.client.post_order(params)
        logger.info("MARKET order response: %s", response)
        return response

    def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        time_in_force: str = "GTC",
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": "LIMIT",
            "quantity": quantity,
            "price": price,
            "timeInForce": time_in_force,
        }
        logger.info(
            "Placing LIMIT order | symbol=%s side=%s qty=%s price=%s tif=%s",
            symbol,
            side,
            quantity,
            price,
            time_in_force,
        )
        response = self.client.post_order(params)
        logger.info("LIMIT order response: %s", response)
        return response

    def place_stop_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        stop_price: float,
        time_in_force: str = "GTC",
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "symbol": symbol,
            "side": side,
            "type": "STOP",
            "quantity": quantity,
            "price": price,
            "stopPrice": stop_price,
            "timeInForce": time_in_force,
        }
        logger.info(
            "Placing STOP_LIMIT order | symbol=%s side=%s qty=%s price=%s stopPrice=%s tif=%s",
            symbol,
            side,
            quantity,
            price,
            stop_price,
            time_in_force,
        )
        response = self.client.post_order(params)
        logger.info("STOP_LIMIT order response: %s", response)
        return response


def format_order_summary(
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: Optional[float] = None,
    stop_price: Optional[float] = None,
    time_in_force: Optional[str] = None,
) -> str:
    lines = [
        "",
        "┌─ Order Request ─────────────────────────────────",
        f"│  Symbol      : {symbol}",
        f"│  Side        : {side}",
        f"│  Type        : {order_type}",
        f"│  Quantity    : {quantity}",
    ]
    if price is not None:
        lines.append(f"│  Price       : {price}")
    if stop_price is not None:
        lines.append(f"│  Stop Price  : {stop_price}")
    if time_in_force:
        lines.append(f"│  TimeInForce : {time_in_force}")
    lines.append("└─────────────────────────────────────────────────")
    return "\n".join(lines)


def format_order_response(response: Dict[str, Any]) -> str:
    lines = [
        "",
        "┌─ Order Response ────────────────────────────────",
        f"│  Order ID    : {response.get('orderId', 'N/A')}",
        f"│  Client ID   : {response.get('clientOrderId', 'N/A')}",
        f"│  Symbol      : {response.get('symbol', 'N/A')}",
        f"│  Side        : {response.get('side', 'N/A')}",
        f"│  Type        : {response.get('type', 'N/A')}",
        f"│  Status      : {response.get('status', 'N/A')}",
        f"│  Orig Qty    : {response.get('origQty', 'N/A')}",
        f"│  Exec Qty    : {response.get('executedQty', 'N/A')}",
        f"│  Avg Price   : {response.get('avgPrice', response.get('price', 'N/A'))}",
    ]
    if response.get("price"):
        lines.append(f"│  Limit Price : {response['price']}")
    if response.get("stopPrice") and response.get("stopPrice") != "0":
        lines.append(f"│  Stop Price  : {response['stopPrice']}")
    lines.append("└─────────────────────────────────────────────────")
    return "\n".join(lines)
