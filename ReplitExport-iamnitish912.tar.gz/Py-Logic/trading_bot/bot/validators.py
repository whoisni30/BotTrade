import re
from typing import Optional


class ValidationError(ValueError):
    pass


VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_LIMIT"}


def validate_symbol(symbol: str) -> str:
    symbol = symbol.strip().upper()
    if not re.fullmatch(r"[A-Z0-9]{3,20}", symbol):
        raise ValidationError(
            f"Invalid symbol '{symbol}'. Expected uppercase letters/digits, e.g. BTCUSDT."
        )
    return symbol


def validate_side(side: str) -> str:
    side = side.strip().upper()
    if side not in VALID_SIDES:
        raise ValidationError(
            f"Invalid side '{side}'. Must be one of: {', '.join(sorted(VALID_SIDES))}."
        )
    return side


def validate_order_type(order_type: str) -> str:
    order_type = order_type.strip().upper()
    if order_type not in VALID_ORDER_TYPES:
        raise ValidationError(
            f"Invalid order type '{order_type}'. Must be one of: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return order_type


def validate_quantity(quantity: str) -> float:
    try:
        qty = float(quantity)
    except (TypeError, ValueError):
        raise ValidationError(f"Invalid quantity '{quantity}'. Must be a positive number.")
    if qty <= 0:
        raise ValidationError(f"Quantity must be greater than zero, got {qty}.")
    return qty


def validate_price(price: Optional[str], label: str = "price") -> float:
    if price is None:
        raise ValidationError(f"'{label}' is required for this order type.")
    try:
        p = float(price)
    except (TypeError, ValueError):
        raise ValidationError(f"Invalid {label} '{price}'. Must be a positive number.")
    if p <= 0:
        raise ValidationError(f"{label.capitalize()} must be greater than zero, got {p}.")
    return p


def validate_time_in_force(tif: Optional[str]) -> str:
    valid = {"GTC", "IOC", "FOK", "GTX"}
    tif = (tif or "GTC").strip().upper()
    if tif not in valid:
        raise ValidationError(
            f"Invalid timeInForce '{tif}'. Must be one of: {', '.join(sorted(valid))}."
        )
    return tif
