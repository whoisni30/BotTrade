import hashlib
import hmac
import os
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests

from .logging_config import get_logger

logger = get_logger(__name__)

BASE_URL = "https://testnet.binancefuture.com"
DEFAULT_TIMEOUT = 10


class BinanceAPIError(Exception):
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceFuturesClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        base_url: str = BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key or os.environ.get("BINANCE_API_KEY", "")
        self.api_secret = api_secret or os.environ.get("BINANCE_API_SECRET", "")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        if not self.api_key or not self.api_secret:
            raise ValueError(
                "Binance API key and secret are required. "
                "Set BINANCE_API_KEY and BINANCE_API_SECRET environment variables."
            )

        self._session = requests.Session()
        self._session.headers.update(
            {
                "X-MBX-APIKEY": self.api_key,
                "Content-Type": "application/x-www-form-urlencoded",
            }
        )
        logger.info("BinanceFuturesClient initialised (base_url=%s)", self.base_url)

    def _sign(self, params: Dict[str, Any]) -> Dict[str, Any]:
        params["timestamp"] = int(time.time() * 1000)
        query_string = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        params["signature"] = signature
        return params

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True,
    ) -> Dict[str, Any]:
        params = params or {}
        if signed:
            params = self._sign(params)

        url = f"{self.base_url}{endpoint}"
        log_params = {k: v for k, v in params.items() if k != "signature"}
        logger.debug("REQUEST %s %s params=%s", method.upper(), endpoint, log_params)

        try:
            if method.upper() == "GET":
                response = self._session.get(url, params=params, timeout=self.timeout)
            elif method.upper() == "POST":
                response = self._session.post(url, data=params, timeout=self.timeout)
            elif method.upper() == "DELETE":
                response = self._session.delete(url, params=params, timeout=self.timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
        except requests.exceptions.ConnectionError as exc:
            logger.error("Network error reaching %s: %s", url, exc)
            raise ConnectionError(f"Network error: could not reach {self.base_url}. {exc}") from exc
        except requests.exceptions.Timeout as exc:
            logger.error("Request timed out (%ss) for %s", self.timeout, url)
            raise TimeoutError(f"Request to {endpoint} timed out after {self.timeout}s.") from exc

        logger.debug(
            "RESPONSE %s %s status=%d body=%s",
            method.upper(),
            endpoint,
            response.status_code,
            response.text[:500],
        )

        try:
            data = response.json()
        except ValueError:
            logger.error("Non-JSON response from %s: %s", endpoint, response.text[:200])
            response.raise_for_status()
            raise

        if isinstance(data, dict) and "code" in data and data["code"] != 200 and data["code"] < 0:
            logger.error(
                "API error from %s: code=%s msg=%s", endpoint, data.get("code"), data.get("msg")
            )
            raise BinanceAPIError(data["code"], data.get("msg", "Unknown error"))

        if not response.ok:
            logger.error("HTTP %d from %s: %s", response.status_code, endpoint, response.text[:300])
            response.raise_for_status()

        return data

    def post_order(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._request("POST", "/fapi/v1/order", params=params, signed=True)

    def get_exchange_info(self) -> Dict[str, Any]:
        return self._request("GET", "/fapi/v1/exchangeInfo", signed=False)

    def get_account(self) -> Dict[str, Any]:
        return self._request("GET", "/fapi/v2/account", signed=True)
