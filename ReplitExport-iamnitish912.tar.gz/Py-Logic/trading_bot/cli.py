#!/usr/bin/env python3
"""
Binance Futures Testnet Trading Bot — CLI entry point.

Usage examples:
  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
  python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 30000
  python cli.py --symbol BTCUSDT --side BUY --type STOP_LIMIT --quantity 0.001 --price 31000 --stop-price 30500
"""

import argparse
import sys

from bot.client import BinanceAPIError, BinanceFuturesClient
from bot.logging_config import get_logger
from bot.orders import OrderPlacer, format_order_response, format_order_summary
from bot.validators import (
    ValidationError,
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_symbol,
    validate_time_in_force,
)

logger = get_logger(__name__)

BANNER = """
╔══════════════════════════════════════════════════════╗
║     Binance Futures Testnet — Trading Bot  v1.0      ║
╚══════════════════════════════════════════════════════╝
"""


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Place orders on Binance Futures Testnet (USDT-M).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Market buy:
    python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

  Limit sell:
    python cli.py --symbol ETHUSDT --side SELL --type LIMIT --quantity 0.05 --price 1800

  Stop-Limit buy:
    python cli.py --symbol BTCUSDT --side BUY --type STOP_LIMIT \\
        --quantity 0.001 --price 31000 --stop-price 30500
        """,
    )

    parser.add_argument(
        "--symbol",
        required=True,
        metavar="SYMBOL",
        help="Trading pair symbol, e.g. BTCUSDT",
    )
    parser.add_argument(
        "--side",
        required=True,
        choices=["BUY", "SELL"],
        metavar="SIDE",
        help="Order side: BUY or SELL",
    )
    parser.add_argument(
        "--type",
        dest="order_type",
        required=True,
        choices=["MARKET", "LIMIT", "STOP_LIMIT"],
        metavar="TYPE",
        help="Order type: MARKET, LIMIT, or STOP_LIMIT",
    )
    parser.add_argument(
        "--quantity",
        required=True,
        metavar="QTY",
        help="Order quantity (e.g. 0.001 for BTC)",
    )
    parser.add_argument(
        "--price",
        default=None,
        metavar="PRICE",
        help="Limit price (required for LIMIT and STOP_LIMIT orders)",
    )
    parser.add_argument(
        "--stop-price",
        dest="stop_price",
        default=None,
        metavar="STOP_PRICE",
        help="Stop trigger price (required for STOP_LIMIT orders)",
    )
    parser.add_argument(
        "--time-in-force",
        dest="time_in_force",
        default="GTC",
        metavar="TIF",
        help="Time-in-force for LIMIT/STOP_LIMIT: GTC (default), IOC, FOK, GTX",
    )
    parser.add_argument(
        "--api-key",
        default=None,
        metavar="API_KEY",
        help="Binance API key (overrides BINANCE_API_KEY env var)",
    )
    parser.add_argument(
        "--api-secret",
        default=None,
        metavar="API_SECRET",
        help="Binance API secret (overrides BINANCE_API_SECRET env var)",
    )
    return parser


def run(args: argparse.Namespace) -> int:
    print(BANNER)

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        order_type = validate_order_type(args.order_type)
        quantity = validate_quantity(args.quantity)

        price: float | None = None
        stop_price: float | None = None
        tif: str = "GTC"

        if order_type == "LIMIT":
            price = validate_price(args.price, label="price")
            tif = validate_time_in_force(args.time_in_force)

        elif order_type == "STOP_LIMIT":
            price = validate_price(args.price, label="price")
            stop_price = validate_price(args.stop_price, label="stop-price")
            tif = validate_time_in_force(args.time_in_force)

    except ValidationError as exc:
        print(f"\n[ERROR] Validation failed: {exc}\n", file=sys.stderr)
        logger.error("Validation error: %s", exc)
        return 1

    print(
        format_order_summary(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price,
            time_in_force=tif if order_type != "MARKET" else None,
        )
    )

    try:
        client = BinanceFuturesClient(
            api_key=args.api_key,
            api_secret=args.api_secret,
        )
        placer = OrderPlacer(client)

        if order_type == "MARKET":
            response = placer.place_market_order(symbol, side, quantity)
        elif order_type == "LIMIT":
            response = placer.place_limit_order(symbol, side, quantity, price, tif)  # type: ignore[arg-type]
        else:
            response = placer.place_stop_limit_order(
                symbol, side, quantity, price, stop_price, tif  # type: ignore[arg-type]
            )

    except ValueError as exc:
        print(f"\n[ERROR] Configuration error: {exc}\n", file=sys.stderr)
        logger.error("Configuration error: %s", exc)
        return 1
    except BinanceAPIError as exc:
        print(f"\n[ERROR] Binance API error (code {exc.code}): {exc.message}\n", file=sys.stderr)
        logger.error("BinanceAPIError code=%s msg=%s", exc.code, exc.message)
        return 1
    except ConnectionError as exc:
        print(f"\n[ERROR] Network error: {exc}\n", file=sys.stderr)
        logger.error("Network error: %s", exc)
        return 1
    except TimeoutError as exc:
        print(f"\n[ERROR] Request timed out: {exc}\n", file=sys.stderr)
        logger.error("Timeout: %s", exc)
        return 1
    except Exception as exc:  # noqa: BLE001
        print(f"\n[ERROR] Unexpected error: {exc}\n", file=sys.stderr)
        logger.exception("Unexpected error: %s", exc)
        return 1

    print(format_order_response(response))
    print("\n  ✔  Order placed successfully!\n")
    logger.info("Order placed successfully | orderId=%s", response.get("orderId"))
    return 0


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    sys.exit(run(args))


if __name__ == "__main__":
    main()
