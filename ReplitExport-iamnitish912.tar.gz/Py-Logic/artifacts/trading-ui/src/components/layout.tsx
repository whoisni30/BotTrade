import { Link, useLocation } from "wouter";
import { LineChart, LayoutDashboard } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row dark">
      {/* Sidebar */}
      <aside className="w-full md:w-64 border-r border-sidebar-border bg-sidebar flex-shrink-0 flex flex-col">
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-sm bg-primary flex items-center justify-center">
              <LineChart className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="font-mono font-bold text-xl tracking-tight text-foreground uppercase">
              Primetrade
            </h1>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <Link href="/">
            <div
              className={`flex items-center gap-3 px-4 py-3 rounded-md cursor-pointer transition-colors ${
                location === "/"
                  ? "bg-sidebar-accent text-sidebar-accent-foreground border border-sidebar-border"
                  : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/50"
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="font-medium text-sm">Trading Panel</span>
            </div>
          </Link>
          <Link href="/history">
            <div
              className={`flex items-center gap-3 px-4 py-3 rounded-md cursor-pointer transition-colors ${
                location === "/history"
                  ? "bg-sidebar-accent text-sidebar-accent-foreground border border-sidebar-border"
                  : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/50"
              }`}
            >
              <LineChart className="w-5 h-5" />
              <span className="font-medium text-sm">Order History</span>
            </div>
          </Link>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-16 border-b border-border bg-card/50 flex items-center px-6 flex-shrink-0">
          <div className="flex items-center justify-between w-full">
            <div className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
              {location === "/" ? "Binance Futures Testnet" : "Order History"}
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]" />
              <span className="text-xs font-mono text-muted-foreground">Connected</span>
            </div>
          </div>
        </header>
        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
