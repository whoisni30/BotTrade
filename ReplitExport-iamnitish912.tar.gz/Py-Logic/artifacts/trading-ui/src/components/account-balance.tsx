import { useGetAccount } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function AccountBalance() {
  const { data: account, isLoading, isError } = useGetAccount();

  if (isLoading) {
    return (
      <Card className="bg-card border-border h-full">
        <CardHeader className="border-b border-border pb-4">
          <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
            Account Balances
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="space-y-2">
            <Skeleton className="h-4 w-32 bg-muted" />
            <Skeleton className="h-8 w-48 bg-muted" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-16 bg-muted rounded-md" />
            <Skeleton className="h-16 bg-muted rounded-md" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isError || !account) {
    return (
      <Card className="bg-card border-border h-full flex flex-col">
        <CardHeader className="border-b border-border pb-4">
          <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
            Account Balances
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 flex-1 flex items-center justify-center">
          <div className="text-sm text-destructive font-mono text-center">
            Failed to load account data.
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatUsd = (val: string) => {
    const num = parseFloat(val);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(num);
  };

  const usdtAsset = account.assets.find((a) => a.asset === "USDT");

  return (
    <Card className="bg-card border-border h-full flex flex-col">
      <CardHeader className="border-b border-border pb-4">
        <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
          Account Balances
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 flex-1 flex flex-col justify-between space-y-6">
        <div>
          <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Total Wallet Balance</p>
          <p className="text-3xl font-mono font-bold text-foreground tracking-tight">
            {formatUsd(account.totalWalletBalance)}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-background border border-border rounded-md">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Available Balance</p>
            <p className="text-lg font-mono font-medium text-foreground tracking-tight">
              {formatUsd(account.availableBalance)}
            </p>
          </div>
          <div className="p-4 bg-background border border-border rounded-md">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Unrealized PnL</p>
            <p
              className={`text-lg font-mono font-medium tracking-tight ${
                parseFloat(account.totalUnrealizedProfit) >= 0
                  ? "text-green-500"
                  : "text-red-500"
              }`}
            >
              {parseFloat(account.totalUnrealizedProfit) >= 0 ? "+" : ""}
              {formatUsd(account.totalUnrealizedProfit)}
            </p>
          </div>
        </div>

        {usdtAsset && (
          <div className="pt-4 border-t border-border">
            <div className="flex justify-between items-center text-sm font-mono">
              <span className="text-muted-foreground">USDT Wallet</span>
              <span className="text-foreground">{parseFloat(usdtAsset.walletBalance).toFixed(2)}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
