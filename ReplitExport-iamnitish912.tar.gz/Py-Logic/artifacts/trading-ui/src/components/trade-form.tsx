import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQueryClient } from "@tanstack/react-query";
import {
  usePlaceOrder,
  getGetOrderHistoryQueryKey,
  getGetAccountQueryKey,
} from "@workspace/api-client-react";
import type { OrderResult } from "@workspace/api-client-react/src/generated/api.schemas";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const formSchema = z.object({
  symbol: z.string().min(1, "Symbol is required").toUpperCase(),
  side: z.enum(["BUY", "SELL"]),
  orderType: z.enum(["MARKET", "LIMIT", "STOP_LIMIT"]),
  quantity: z.coerce.number().positive("Quantity must be positive"),
  price: z.coerce.number().positive("Price must be positive").optional().nullable(),
  stopPrice: z.coerce.number().positive("Stop price must be positive").optional().nullable(),
  timeInForce: z.enum(["GTC", "IOC", "FOK", "GTX"]).optional().nullable(),
});

type FormValues = z.infer<typeof formSchema>;

export function TradeForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const placeOrder = usePlaceOrder();
  const [lastResult, setLastResult] = useState<OrderResult | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      symbol: "BTCUSDT",
      side: "BUY",
      orderType: "MARKET",
      quantity: 0.01,
      timeInForce: "GTC",
    },
  });

  const orderType = form.watch("orderType");
  const side = form.watch("side");

  const onSubmit = (data: FormValues) => {
    setLastResult(null);
    placeOrder.mutate(
      { data },
      {
        onSuccess: (result) => {
          setLastResult(result);
          toast({
            title: "Order Placed Successfully",
            description: `Order ID: ${result.orderId}`,
          });
          queryClient.invalidateQueries({ queryKey: getGetOrderHistoryQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetAccountQueryKey() });
          form.reset({
            ...form.getValues(),
            quantity: data.quantity, // Keep symbol and quantity
          });
        },
        onError: (error: any) => {
          toast({
            title: "Order Failed",
            description: error.response?.data?.error || error.message || "An error occurred",
            variant: "destructive",
          });
        },
      }
    );
  };

  const isBuy = side === "BUY";

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader className="border-b border-border pb-4">
          <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
            Place Order
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="symbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Symbol</FormLabel>
                      <FormControl>
                        <Input {...field} className="font-mono bg-background border-border uppercase" placeholder="BTCUSDT" />
                      </FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="orderType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Order Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="font-mono bg-background border-border">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-popover border-border">
                          <SelectItem value="MARKET" className="font-mono">Market</SelectItem>
                          <SelectItem value="LIMIT" className="font-mono">Limit</SelectItem>
                          <SelectItem value="STOP_LIMIT" className="font-mono">Stop Limit</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex bg-background border border-border p-1 rounded-md">
                <Button
                  type="button"
                  variant={isBuy ? "default" : "ghost"}
                  className={`flex-1 font-mono text-sm uppercase rounded-sm h-10 transition-colors ${
                    isBuy ? "bg-green-500/20 text-green-500 hover:bg-green-500/30" : "text-muted-foreground hover:bg-muted/50"
                  }`}
                  onClick={() => form.setValue("side", "BUY")}
                >
                  Buy / Long
                </Button>
                <Button
                  type="button"
                  variant={!isBuy ? "default" : "ghost"}
                  className={`flex-1 font-mono text-sm uppercase rounded-sm h-10 transition-colors ${
                    !isBuy ? "bg-red-500/20 text-red-500 hover:bg-red-500/30" : "text-muted-foreground hover:bg-muted/50"
                  }`}
                  onClick={() => form.setValue("side", "SELL")}
                >
                  Sell / Short
                </Button>
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Quantity</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.001" {...field} className="font-mono bg-background border-border" />
                      </FormControl>
                      <FormMessage className="text-xs" />
                    </FormItem>
                  )}
                />

                {(orderType === "LIMIT" || orderType === "STOP_LIMIT") && (
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Limit Price</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} value={field.value || ""} className="font-mono bg-background border-border" />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                )}

                {orderType === "STOP_LIMIT" && (
                  <FormField
                    control={form.control}
                    name="stopPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Stop Price</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} value={field.value || ""} className="font-mono bg-background border-border" />
                        </FormControl>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                )}

                {(orderType === "LIMIT" || orderType === "STOP_LIMIT") && (
                  <FormField
                    control={form.control}
                    name="timeInForce"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Time In Force</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || "GTC"}>
                          <FormControl>
                            <SelectTrigger className="font-mono bg-background border-border">
                              <SelectValue placeholder="Select TIF" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-popover border-border">
                            <SelectItem value="GTC" className="font-mono">GTC (Good Till Cancel)</SelectItem>
                            <SelectItem value="IOC" className="font-mono">IOC (Immediate Or Cancel)</SelectItem>
                            <SelectItem value="FOK" className="font-mono">FOK (Fill Or Kill)</SelectItem>
                            <SelectItem value="GTX" className="font-mono">GTX (Post Only)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage className="text-xs" />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              {placeOrder.error && (
                <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle className="font-mono text-sm uppercase">Order Failed</AlertTitle>
                  <AlertDescription className="text-xs font-mono">
                    {(placeOrder.error as any).response?.data?.error || placeOrder.error.message || "Unknown error"}
                  </AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                disabled={placeOrder.isPending}
                className={`w-full font-mono font-bold tracking-wider uppercase h-12 ${
                  isBuy
                    ? "bg-green-600 hover:bg-green-700 text-white"
                    : "bg-red-600 hover:bg-red-700 text-white"
                }`}
              >
                {placeOrder.isPending ? "Placing Order..." : `${isBuy ? "Buy" : "Sell"} ${form.getValues("symbol")}`}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {lastResult && (
        <Alert className="bg-card border-border">
          <CheckCircle2 className="h-5 w-5 text-primary" />
          <AlertTitle className="font-mono text-sm text-foreground mb-2 flex items-center gap-2">
            <span className="text-primary font-bold">SUCCESS</span> 
            <span className="text-muted-foreground">|</span>
            Order {lastResult.orderId}
          </AlertTitle>
          <AlertDescription>
            <div className="grid grid-cols-2 gap-x-4 gap-y-2 mt-4 text-xs font-mono">
              <div className="text-muted-foreground">Symbol</div>
              <div className="text-foreground text-right">{lastResult.symbol}</div>
              
              <div className="text-muted-foreground">Status</div>
              <div className="text-foreground text-right">{lastResult.status}</div>
              
              <div className="text-muted-foreground">Executed Qty</div>
              <div className="text-foreground text-right">{lastResult.executedQty} / {lastResult.origQty}</div>
              
              <div className="text-muted-foreground">Avg Price</div>
              <div className="text-foreground text-right">${parseFloat(lastResult.avgPrice || "0").toFixed(2)}</div>
            </div>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
