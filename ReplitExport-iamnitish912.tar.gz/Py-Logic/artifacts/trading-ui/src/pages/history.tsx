import { useGetOrderHistory } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function History() {
  const { data: records, isLoading, isError } = useGetOrderHistory();

  return (
    <Layout>
      <div className="max-w-7xl mx-auto h-full flex flex-col">
        <Card className="bg-card border-border flex-1 flex flex-col">
          <CardHeader className="border-b border-border pb-4">
            <CardTitle className="text-sm font-mono text-muted-foreground uppercase tracking-wider">
              Order History
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 flex-1 overflow-auto">
            {isLoading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full bg-muted" />
                ))}
              </div>
            ) : isError ? (
              <div className="p-12 text-center flex flex-col items-center">
                <div className="text-destructive font-mono text-sm uppercase">Failed to load history</div>
              </div>
            ) : !records || records.length === 0 ? (
              <div className="p-16 text-center flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-muted/20 border border-border flex items-center justify-center mb-4">
                  <svg className="w-8 h-8 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path>
                  </svg>
                </div>
                <h3 className="text-foreground font-mono uppercase tracking-widest text-sm mb-2">No Order History</h3>
                <p className="text-muted-foreground text-sm font-mono">Your placed orders will appear here.</p>
              </div>
            ) : (
              <div className="w-full overflow-auto">
                <table className="w-full text-left font-mono text-sm whitespace-nowrap">
                  <thead className="bg-background/50 border-b border-border text-muted-foreground sticky top-0">
                    <tr>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs">Date</th>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs">Symbol</th>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs">Side / Type</th>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs text-right">Price</th>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs text-right">Qty</th>
                      <th className="px-6 py-4 font-normal uppercase tracking-wider text-xs text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {records.map((record) => (
                      <tr key={record.id} className="hover:bg-muted/30 transition-colors">
                        <td className="px-6 py-4 text-muted-foreground">
                          {format(new Date(record.placedAt), "MMM dd, HH:mm:ss")}
                        </td>
                        <td className="px-6 py-4 text-foreground font-bold">
                          {record.request.symbol}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-sm text-xs font-bold mr-2 ${
                            record.request.side === "BUY" ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
                          }`}>
                            {record.request.side}
                          </span>
                          <span className="text-muted-foreground">
                            {record.request.orderType}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right text-foreground">
                          {record.request.orderType === "MARKET" ? "MARKET" : `$${record.request.price?.toFixed(2) || "0.00"}`}
                        </td>
                        <td className="px-6 py-4 text-right text-foreground">
                          {record.request.quantity}
                        </td>
                        <td className="px-6 py-4 text-center">
                          {!record.success ? (
                            <span className="px-2 py-1 bg-destructive/20 text-destructive text-xs uppercase rounded-sm">
                              Failed
                            </span>
                          ) : (
                            <span className={`px-2 py-1 text-xs uppercase rounded-sm ${
                              record.result.status === "FILLED" ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                            }`}>
                              {record.result.status}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
