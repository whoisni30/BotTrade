import { Layout } from "@/components/layout";
import { TradeForm } from "@/components/trade-form";
import { AccountBalance } from "@/components/account-balance";

export default function Home() {
  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full max-w-7xl mx-auto">
        <div className="lg:col-span-8 flex flex-col gap-6">
          <AccountBalance />
          <div className="bg-card border border-border p-6 rounded-lg flex-1 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-muted/50 border border-border flex items-center justify-center mb-4">
              <svg className="w-8 h-8 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
              </svg>
            </div>
            <h3 className="text-foreground font-mono uppercase tracking-widest text-sm mb-2">Market Data Not Available</h3>
            <p className="text-muted-foreground text-sm font-mono max-w-sm">Chart integration requires a separate market data provider. Place orders using the terminal panel.</p>
          </div>
        </div>
        <div className="lg:col-span-4 h-full">
          <TradeForm />
        </div>
      </div>
    </Layout>
  );
}
