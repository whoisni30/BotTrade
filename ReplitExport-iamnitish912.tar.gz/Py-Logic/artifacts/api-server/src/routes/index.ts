import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ordersRouter from "./orders";
import accountRouter from "./account";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/orders", ordersRouter);
router.use("/account", accountRouter);

export default router;
