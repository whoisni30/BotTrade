import { Router, Request, Response } from "express";
import { binanceGet, BinanceAPIError } from "../lib/binance";
import { logger } from "../lib/logger";

const router = Router();

router.get("/", async (_req: Request, res: Response) => {
  try {
    const account = await binanceGet("/fapi/v2/account") as Record<string, unknown>;

    const assets = (account["assets"] as Array<Record<string, unknown>> ?? [])
      .filter((a) => parseFloat(String(a["walletBalance"] ?? "0")) > 0)
      .map((a) => ({
        asset: String(a["asset"] ?? ""),
        walletBalance: String(a["walletBalance"] ?? "0"),
        availableBalance: String(a["availableBalance"] ?? "0"),
        unrealizedProfit: String(a["unrealizedProfit"] ?? "0"),
      }));

    res.json({
      totalWalletBalance: String(account["totalWalletBalance"] ?? "0"),
      totalUnrealizedProfit: String(account["totalUnrealizedProfit"] ?? "0"),
      availableBalance: String(account["availableBalance"] ?? "0"),
      assets,
    });
  } catch (err) {
    if (err instanceof BinanceAPIError) {
      logger.warn({ code: err.code, msg: err.message }, "Binance API error fetching account");
      res.status(502).json({ error: `Binance error ${err.code}: ${err.message}`, code: err.code });
    } else if (err instanceof Error && err.message.includes("BINANCE_API_KEY")) {
      logger.warn("Binance credentials not configured");
      res.status(502).json({ error: err.message, code: null });
    } else {
      logger.error({ err }, "Unexpected error fetching account");
      res.status(502).json({ error: "Failed to fetch account info", code: null });
    }
  }
});

export default router;
