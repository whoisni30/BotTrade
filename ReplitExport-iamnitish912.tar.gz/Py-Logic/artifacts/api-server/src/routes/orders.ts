import { Router, Request, Response } from "express";
import { db, ordersTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { PlaceOrderBody } from "@workspace/api-zod";
import { binancePost, binanceGet, BinanceAPIError } from "../lib/binance";
import { logger } from "../lib/logger";

const router = Router();

router.post("/", async (req: Request, res: Response) => {
  const parsed = PlaceOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body", code: null });
    return;
  }

  const { symbol, side, orderType, quantity, price, stopPrice, timeInForce } = parsed.data;

  const params: Record<string, string | number> = {
    symbol: symbol.toUpperCase(),
    side,
    quantity,
    type: orderType === "STOP_LIMIT" ? "STOP" : orderType,
  };

  if (orderType === "LIMIT" || orderType === "STOP_LIMIT") {
    if (!price) {
      res.status(400).json({ error: "price is required for LIMIT and STOP_LIMIT orders", code: null });
      return;
    }
    params["price"] = price;
    params["timeInForce"] = timeInForce ?? "GTC";
  }

  if (orderType === "STOP_LIMIT") {
    if (!stopPrice) {
      res.status(400).json({ error: "stopPrice is required for STOP_LIMIT orders", code: null });
      return;
    }
    params["stopPrice"] = stopPrice;
  }

  let result: unknown;
  let success = false;
  let errorMessage: string | undefined;

  try {
    result = await binancePost("/fapi/v1/order", params);
    success = true;
    logger.info({ orderId: (result as Record<string, unknown>)["orderId"] }, "Order placed successfully");
  } catch (err) {
    if (err instanceof BinanceAPIError) {
      errorMessage = `Binance error ${err.code}: ${err.message}`;
      logger.warn({ code: err.code, msg: err.message }, "Binance API error placing order");
    } else {
      errorMessage = err instanceof Error ? err.message : "Unknown error";
      logger.error({ err }, "Unexpected error placing order");
    }
  }

  await db.insert(ordersTable).values({
    symbol: symbol.toUpperCase(),
    side,
    orderType,
    quantity: String(quantity),
    price: price != null ? String(price) : null,
    stopPrice: stopPrice != null ? String(stopPrice) : null,
    timeInForce: timeInForce ?? null,
    success,
    orderId: success ? String((result as Record<string, unknown>)["orderId"]) : null,
    status: success ? String((result as Record<string, unknown>)["status"]) : null,
    executedQty: success ? String((result as Record<string, unknown>)["executedQty"]) : null,
    avgPrice: success ? String((result as Record<string, unknown>)["avgPrice"]) : null,
    rawRequest: params as Record<string, unknown>,
    rawResponse: success ? (result as Record<string, unknown>) : null,
    errorMessage: errorMessage ?? null,
  });

  if (!success) {
    const statusCode = errorMessage?.startsWith("Binance error") ? 502 : 400;
    const codeMatch = errorMessage?.match(/Binance error (-?\d+)/);
    res.status(statusCode).json({
      error: errorMessage,
      code: codeMatch ? parseInt(codeMatch[1]) : null,
    });
    return;
  }

  res.json(result);
});

router.get("/history", async (_req: Request, res: Response) => {
  const rows = await db
    .select()
    .from(ordersTable)
    .orderBy(desc(ordersTable.placedAt))
    .limit(100);

  const records = rows.map((row) => ({
    id: row.id,
    placedAt: row.placedAt.toISOString(),
    success: row.success,
    errorMessage: row.errorMessage ?? null,
    request: {
      symbol: row.symbol,
      side: row.side,
      orderType: row.orderType,
      quantity: parseFloat(row.quantity),
      price: row.price != null ? parseFloat(row.price) : null,
      stopPrice: row.stopPrice != null ? parseFloat(row.stopPrice) : null,
      timeInForce: row.timeInForce ?? null,
    },
    result: row.rawResponse ?? {
      orderId: row.orderId ? parseInt(row.orderId) : 0,
      clientOrderId: "",
      symbol: row.symbol,
      side: row.side,
      type: row.orderType,
      status: row.status ?? "",
      origQty: row.quantity,
      executedQty: row.executedQty ?? "0",
      avgPrice: row.avgPrice ?? "0",
      price: row.price ?? "0",
      stopPrice: row.stopPrice ?? null,
      timeInForce: row.timeInForce ?? null,
      updateTime: 0,
    },
  }));

  res.json(records);
});

export default router;
